<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method = "POST">
    <input type="text" name = "ad" placeholder="adınızı girin">
    <input type="submit" value="Formu gönder" name = "">
        
   
   
</form>
<?php
 
    echo $_POST["ad"]


?>

</body>
</html>